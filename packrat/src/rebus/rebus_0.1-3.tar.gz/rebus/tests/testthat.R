library(testthat)
library(rebus)

test_check("rebus")

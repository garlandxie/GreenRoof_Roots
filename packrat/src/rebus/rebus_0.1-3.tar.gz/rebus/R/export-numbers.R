# From rebus.numbers number-range.R

#' Generate a regular expression for a number range
#' 
#' See \code{\link[rebus.numbers]{number_range}}.
#' @name number_range
#' @export number_range
NULL 


# From rebus.numbers roman.R

#' Roman numerals
#' 
#' See \code{\link[rebus.numbers]{roman}}.
#' @name roman
#' @aliases ROMAN
#' @export roman
#' @export ROMAN
NULL 

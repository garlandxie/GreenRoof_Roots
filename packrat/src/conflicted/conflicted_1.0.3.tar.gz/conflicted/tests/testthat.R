library(testthat)
library(conflicted)

test_check("conflicted")

.onAttach <- function(libname, pkgname) {

  packageStartupMessage("
  This is piecewiseSEM version 2.0.2\n
  If you have used the package before, it is strongly recommended you read Section 3 of the vignette('piecewiseSEM') to familiarize yourself with the new syntax\n
  Questions or bugs can be addressed to <jlefcheck@bigelow.org>")

  }
